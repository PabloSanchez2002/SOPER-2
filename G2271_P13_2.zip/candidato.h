#ifndef CANDIDATO_H
#define CANDIDATO_H

// extern int VARIABLES

void soy_candidato(process_info pinf);

#endif